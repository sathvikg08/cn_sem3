"""Web front end for the distributed backup system + SDN network.

Run from the project root:  python -m web.app   ->  http://127.0.0.1:5000

Environment:
  BACKUP_SERVERS   comma-separated server endpoints (default 127.0.0.1:9101,127.0.0.1:9102)
  SDN_STATE_URL    controller state endpoint (default http://127.0.0.1:8081/sdn/state)
"""
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from flask import Flask, jsonify, request, send_file, send_from_directory

from client.core import BackupClient, BackupError, endpoint_label, parse_endpoint, servers_from_env
from web.sdn_model import SdnModel, fetch_live

ROOT = Path(__file__).resolve().parent.parent
HERE = Path(__file__).parent

app = Flask(__name__, static_folder=None)
sdn = SdnModel()
config = {"servers": os.environ.get("BACKUP_SERVERS", "")}
managed = {}  # "A"/"B" -> subprocess started from this UI


def endpoints():
    return servers_from_env(config["servers"] or None)


def client(only=None):
    return BackupClient([only] if only else endpoints())


# ------------------------------------------------------------------ pages
@app.get("/")
def index():
    return send_from_directory(HERE, "index.html")


# ---------------------------------------------------------------- config
@app.get("/api/config")
def get_config():
    return jsonify({"servers": ",".join(endpoint_label(e) for e in endpoints())})


@app.post("/api/config")
def set_config():
    value = (request.get_json() or {}).get("servers", "").strip()
    try:
        servers_from_env(value or None)
    except Exception as exc:
        return jsonify({"error": f"invalid endpoint list: {exc}"}), 400
    config["servers"] = value
    return get_config()


# --------------------------------------------------------------- servers
@app.get("/api/status")
def status():
    result = client().status_all()
    for i, entry in enumerate(result):
        name = "AB"[i] if i < 2 else str(i)
        proc = managed.get(name)
        entry["role"] = "Primary" if i == 0 else "Replica" if i == 1 else "Extra"
        entry["managed"] = bool(proc and proc.poll() is None)
    return jsonify(result)


@app.post("/api/servers/<name>/<action>")
def control_server(name, action):
    """Start or stop a backup server (needed to demonstrate failover)."""
    eps = endpoints()
    idx = {"A": 0, "B": 1}.get(name)
    if idx is None or idx >= len(eps) or action not in ("start", "stop"):
        return jsonify({"error": "unknown server or action"}), 400
    proc = managed.get(name)
    running = bool(proc and proc.poll() is None)
    if action == "stop":
        if not running:
            return jsonify({"error": f"Server {name} was not started from this page; stop it where you launched it."}), 409
        proc.terminate()
        proc.wait(timeout=5)
        return jsonify({"ok": True})
    if running:
        return jsonify({"ok": True})
    host, port = eps[idx]
    cmd = [sys.executable, "-m", "server", "--node", name, "--host", host, "--port", str(port),
           "--data-dir", str(ROOT / "data" / f"server-{name.lower()}")]
    if name == "A" and len(eps) > 1:
        cmd += ["--peer", endpoint_label(eps[1])]
    managed[name] = subprocess.Popen(cmd, cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return jsonify({"ok": True})


# ----------------------------------------------------------------- files
@app.get("/api/files")
def files():
    """Merge the file lists of every server so files held only on B still show."""
    merged, servers = {}, []
    for ep in endpoints():
        label = endpoint_label(ep)
        try:
            resp = client(ep).list_files()
        except BackupError as exc:
            servers.append({"endpoint": label, "online": False, "error": str(exc)})
            continue
        node = resp.get("server_node") or label
        servers.append({"endpoint": label, "online": True, "node": node})
        for f in resp["files"]:
            entry = merged.setdefault(f["file_id"], {**f, "nodes": []})
            entry["nodes"].append(node)
    return jsonify({"files": sorted(merged.values(), key=lambda f: f["created_at"]), "servers": servers})


@app.post("/api/upload")
def upload():
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "No file selected"}), 400
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "upload"
        f.save(path)
        try:
            return jsonify(client().upload_file(path, remote_name=f.filename))
        except BackupError as exc:
            return jsonify({"error": str(exc)}), 502


@app.get("/api/restore/<file_id>")
def restore(file_id):
    name = request.args.get("name") or file_id
    dest = Path(tempfile.mkdtemp()) / "restored"
    try:
        result = client().restore_file(file_id, dest, overwrite=True)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 502
    resp = send_file(dest, as_attachment=True, download_name=name)
    resp.headers["X-Served-By"] = str(result.get("node") or result.get("endpoint"))
    resp.headers["X-Verified"] = str(bool(result.get("verified", True))).lower()
    resp.headers["Access-Control-Expose-Headers"] = "X-Served-By, X-Verified"
    return resp


@app.delete("/api/files/<file_id>")
def delete(file_id):
    try:
        return jsonify(client().delete_file(file_id))
    except BackupError as exc:
        return jsonify({"error": str(exc)}), 502


# ------------------------------------------------------------------- sdn
@app.get("/api/sdn")
def sdn_state():
    live = fetch_live()
    return jsonify({"live": live, "model": sdn.snapshot()})


@app.post("/api/sdn/link")
def sdn_link():
    data = request.get_json() or {}
    if not sdn.set_link(str(data.get("id", "")), bool(data.get("up"))):
        return jsonify({"error": "unknown link"}), 400
    return sdn_state()


@app.post("/api/sdn/reset")
def sdn_reset():
    sdn.reset()
    return sdn_state()


@app.teardown_appcontext
def _noop(_exc):
    pass


if __name__ == "__main__":
    try:
        app.run(host="127.0.0.1", port=5000)
    finally:
        for p in managed.values():
            if p.poll() is None:
                p.terminate()
