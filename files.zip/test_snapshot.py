"""Tests for the JSON snapshot shared by the controller and the web UI."""

import json

from sdn.forwarding import route_for_hosts
from sdn.snapshot import build_snapshot
from sdn.topology import HostLocation, Link, NetworkGraph, PortRef


def _graph():
    g = NetworkGraph()
    for dpid, ports in ((1, (1, 2, 3)), (2, (1, 2)), (3, (1, 2)), (4, (1, 2, 3))):
        g.add_switch(dpid, ports=ports)
    for a, b in (((1, 2), (2, 1)), ((2, 2), (4, 1)), ((1, 3), (3, 1)), ((3, 2), (4, 2))):
        g.add_link(Link(PortRef(*a), PortRef(*b)))
    return g


def test_snapshot_is_json_serialisable_and_complete():
    g = _graph()
    h1 = HostLocation("02:00:00:00:00:01", 1, 1, "10.0.0.1")
    h2 = HostLocation("02:00:00:00:00:02", 4, 3, "10.0.0.2")
    plan = route_for_hosts(g, h1, h2, flow_key=1)
    snap = build_snapshot(g, [h1, h2], {(h1.mac, h2.mac): plan}, {"k": 1})
    json.dumps(snap)
    assert len(snap["switches"]) == 4 and len(snap["links"]) == 4
    assert snap["routes"][0]["path"][0] == 1 and snap["routes"][0]["path"][-1] == 4
    assert len(snap["routes"][0]["forward_rules"]) == 3
    assert snap["arp_flood"] and snap["spanning_tree"]["1"]
    assert snap["extra"] == {"k": 1}


def test_failed_link_marked_down():
    g = _graph()
    g.set_port_state(1, 2, False)
    snap = build_snapshot(g, [], {})
    assert [l["up"] for l in snap["links"]].count(False) == 1
