"""JSON-friendly snapshot of controller state.

Shared by the OS-Ken controller (live REST endpoint) and the web front end's
topology model, so both render through the same schema.
"""

from __future__ import annotations

from typing import Any, Iterable, Mapping

from sdn.forwarding import RoutePlan, controlled_flood_targets
from sdn.topology import HostLocation, NetworkGraph, PortRef


def _rule(rule: Any) -> dict[str, Any]:
    return {
        "switch": rule.dpid,
        "in_port": rule.match.in_port,
        "eth_src": rule.match.eth_src,
        "eth_dst": rule.match.eth_dst,
        "out_port": rule.out_port,
    }


def route_dict(
    plan: RoutePlan,
    hosts: Mapping[str, HostLocation],
    src_mac: str,
    dst_mac: str,
) -> dict[str, Any]:
    src, dst = hosts.get(src_mac), hosts.get(dst_mac)
    return {
        "src_mac": src_mac,
        "dst_mac": dst_mac,
        "src_ip": src.ip if src else None,
        "dst_ip": dst.ip if dst else None,
        "path": list(plan.path.nodes),
        "cost": plan.path.cost,
        "reason": plan.selection.reason,
        "detail": plan.selection.detail,
        "forward_rules": [_rule(r) for r in plan.forward],
        "reverse_rules": [_rule(r) for r in plan.reverse],
    }


def build_snapshot(
    graph: NetworkGraph,
    hosts: Iterable[HostLocation],
    routes: Mapping[tuple[str, str], RoutePlan],
    extra: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    host_list = list(hosts)
    by_mac = {h.mac: h for h in host_list}
    topo = graph.to_dict()
    for link in topo["links"]:
        link["id"] = f"{link['a']}|{link['b']}"
    spanning = {
        str(dpid): sorted(ports)
        for dpid, ports in sorted(graph.spanning_tree_ports().items())
    }
    # ARP flood targets for a broadcast entering at each known host port.
    flood = {}
    for host in host_list:
        if graph.has_switch(host.dpid):
            targets = controlled_flood_targets(graph, host.port)
            flood[f"{host.ip or host.mac}@{host.dpid}:{host.port_no}"] = [
                f"{t.dpid}:{t.port_no}" for t in targets
            ]
    return {
        "switches": topo["switches"],
        "links": topo["links"],
        "hosts": [
            {"mac": h.mac, "ip": h.ip, "dpid": h.dpid, "port": h.port_no}
            for h in host_list
        ],
        "spanning_tree": spanning,
        "arp_flood": flood,
        "routes": [
            route_dict(plan, by_mac, src, dst)
            for (src, dst), plan in sorted(routes.items())
        ],
        "extra": dict(extra or {}),
    }
