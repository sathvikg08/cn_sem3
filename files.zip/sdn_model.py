"""Simulation of the Mininet dual-path topology, plus a client for the live
controller state endpoint.

The model uses the project's own sdn/ package (graph, Dijkstra routing, flow
planning). Failing a link recomputes everything exactly as the controller would
after a port-down event.
"""
import itertools
import json
import os
import time
import urllib.request

from sdn.forwarding import route_for_hosts
from sdn.snapshot import build_snapshot
from sdn.topology import HostLocation, Link, NetworkGraph, PortRef

# Mirrors mininet_dual_path_network_topology.py
LINKS = [((1, 2), (2, 1)), ((2, 2), (4, 1)), ((1, 3), (3, 1)), ((3, 2), (4, 2))]
HOSTS = [
    HostLocation("02:00:00:00:00:01", 1, 1, "10.0.0.1"),  # client h1
    HostLocation("02:00:00:00:00:02", 4, 3, "10.0.0.2"),  # server A
    HostLocation("02:00:00:00:00:03", 4, 4, "10.0.0.3"),  # server B
]
HOST_NAMES = {"10.0.0.1": "Client", "10.0.0.2": "Server A", "10.0.0.3": "Server B"}
STATE_URL = os.environ.get("SDN_STATE_URL", "http://127.0.0.1:8081/sdn/state")


def fetch_live(timeout=0.6):
    """Return the controller's snapshot, or None when it is not reachable."""
    try:
        with urllib.request.urlopen(STATE_URL, timeout=timeout) as resp:
            return json.load(resp)
    except Exception:
        return None


class SdnModel:
    def __init__(self):
        self.reset()

    def reset(self):
        g = NetworkGraph()
        g.add_switch(1, ports=(1, 2, 3), name="s1")
        g.add_switch(2, ports=(1, 2), name="s2")
        g.add_switch(3, ports=(1, 2), name="s3")
        g.add_switch(4, ports=(1, 2, 3, 4), name="s4")
        for a, b in LINKS:
            g.add_link(Link(PortRef(*a), PortRef(*b)))
        self.graph = g
        self.log = []
        self.note("Topology loaded: 4 switches, 4 links, 3 hosts.")

    def note(self, text):
        self.log.insert(0, {"time": time.strftime("%H:%M:%S"), "text": text})
        del self.log[50:]

    def set_link(self, link_id, up):
        try:
            a, b = (PortRef(*map(int, part.split(":"))) for part in link_id.split("|"))
        except ValueError:
            return False
        if Link(a, b).key not in {l.key for l in self.graph.links}:
            return False
        self.graph.set_port_state(a.dpid, a.port_no, up)
        self.graph.set_port_state(b.dpid, b.port_no, up)
        self.note(f"Link {a} <-> {b} {'restored' if up else 'FAILED'}; routes recomputed.")
        return True

    def snapshot(self):
        routes = {}
        for src, dst in itertools.combinations(HOSTS, 2):
            plan = route_for_hosts(self.graph, src, dst, flow_key=(src.mac, dst.mac))
            if plan is not None:
                routes[(src.mac, dst.mac)] = plan
        snap = build_snapshot(self.graph, HOSTS, routes, {"events": self.log})
        snap["unrouted"] = [
            f"{HOST_NAMES[s.ip]} -> {HOST_NAMES[d.ip]}"
            for s, d in itertools.combinations(HOSTS, 2)
            if (s.mac, d.mac) not in routes
        ]
        return snap
